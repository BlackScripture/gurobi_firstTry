import com.gurobi.gurobi.*;

public class EdgeMatchingPuzzle {
    public static void main(String[] args) {
        try {
            // Puzzle-Daten
            int[][] parts = {
                    /*
                    {0, 1, 2, 3}, // Teil 1
                    {1, 3, 0, 2}, // Teil 2
                    {2, 1, 3, 0}, // Teil 3
                    {3, 0, 1, 2}  // Teil 4

                     */

                    {0,1,2,3},
                    {0,1,2,1},
                    {2,1,2,3},
                    {2,1,2,1}
            };
            int numParts = parts.length;
            int numPositions = 4; // 2x2-Grid
            int numRotations = 4; // 0°, 90°, 180°, 270°

            // Modell erstellen
            GRBEnv env = new GRBEnv(true);
            env.set("logFile", "edge_matching.log");
            env.start();
            GRBModel model = new GRBModel(env);

            // Entscheidungsvariablen: x[i][j][k] = 1, falls Teil i in Position j mit Rotation k ist
            GRBVar[][][] x = new GRBVar[numParts][numPositions][numRotations];
            for (int i = 0; i < numParts; i++) {
                for (int j = 0; j < numPositions; j++) {
                    for (int k = 0; k < numRotations; k++) {
                        x[i][j][k] = model.addVar(0, 1, 0, GRB.BINARY,
                                "x_" + i + "_" + j + "_" + k);
                    }
                }
            }

            // Jede Position wird von genau einem Teil besetzt
            for (int j = 0; j < numPositions; j++) {
                GRBLinExpr expr = new GRBLinExpr();
                for (int i = 0; i < numParts; i++) {
                    for (int k = 0; k < numRotations; k++) {
                        expr.addTerm(1, x[i][j][k]);
                    }
                }
                model.addConstr(expr, GRB.EQUAL, 2, "Pos_" + j); // auf einem feld, = , 2 , belegungen
            }
/*
            // Jedes Teil wird genau einmal verwendet
            for (int i = 0; i < numParts; i++) {
                GRBLinExpr expr = new GRBLinExpr();
                for (int j = 0; j < numPositions; j++) {
                    for (int k = 0; k < numRotations; k++) {
                        expr.addTerm(1, x[i][j][k]);
                    }
                }
                model.addConstr(expr, GRB.EQUAL, 1, "Part_" + i);
            }

 */
/*
            // Matching-Bedingungen zwischen benachbarten Positionen
            int[][] neighbors = {{0, 1}, {1, 3}, {3, 2}, {2, 0}}; // z. B. (0, 1) ist benachbart
            for (int[] pair : neighbors) {
                int pos1 = pair[0];
                int pos2 = pair[1];
                for (int r1 = 0; r1 < numRotations; r1++) {
                    for (int r2 = 0; r2 < numRotations; r2++) {
                        GRBLinExpr expr = new GRBLinExpr();
                        for (int i1 = 0; i1 < numParts; i1++) {
                            for (int i2 = 0; i2 < numParts; i2++) {
                                int edge1 = parts[i1][r1 % 4];
                                int edge2 = parts[i2][(r2 + 2) % 4];
                                if (edge1 == edge2) {
                                    expr.addTerm(1, x[i1][pos1][r1]);
                                    expr.addTerm(1, x[i2][pos2][r2]);
                                }
                            }
                        }
                        model.addConstr(expr, GRB.GREATER_EQUAL, 1,
                                "Match_" + pos1 + "_" + pos2);
                    }
                }
            }

 */

            // Optimieren
            model.optimize();

            // Ergebnisse ausgeben
            if (model.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL) {
                System.out.println("Optimale Lösung gefunden:");
                for (int i = 0; i < numParts; i++) {
                    for (int j = 0; j < numPositions; j++) {
                        for (int k = 0; k < numRotations; k++) {
                            if (x[i][j][k].get(GRB.DoubleAttr.X) > 0.5) {
                                System.out.println("Teil " + (i + 1) + " in Position " + j +
                                        " mit Rotation " + (k * 90) + "°");
                            }
                        }
                    }
                }
            } else {
                System.out.println("Keine Lösung gefunden.");
            }

            // Aufräumen
            model.dispose();
            env.dispose();
        } catch (GRBException e) {
            System.out.println("Error code: " + e.getErrorCode() + ". " + e.getMessage());
        }
    }
}