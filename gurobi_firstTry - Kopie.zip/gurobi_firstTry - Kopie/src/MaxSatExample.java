import com.gurobi.gurobi.*;

public class MaxSatExample {
    public static void main(String[] args) {
        try {
            // Erstelle ein neues Gurobi-Modell
            GRBEnv env = new GRBEnv(true);
            env.set("logFile", "WeightedMaxSAT.log");
            env.start();
            GRBModel model = new GRBModel(env);

            // Füge Boolesche Variablen hinzu
            GRBVar x1 = model.addVar(0, 1, 0, GRB.BINARY, "x1");
            GRBVar x2 = model.addVar(0, 1, 0, GRB.BINARY, "x2");

            // Hilfsvariable für die weiche Klausel
            GRBVar s1 = model.addVar(0, 1, 0, GRB.BINARY, "slack_1");

            // Weiche Klausel: x1 OR NOT x2
            // Entspricht: x1 - x2 + s1 >= 0
            GRBLinExpr expr = new GRBLinExpr();
            expr.addTerm(1.0, x1);
            expr.addTerm(-1.0, x2);
            expr.addTerm(1.0, s1);
            model.addConstr(expr, GRB.EQUAL, 1, "soft_clause_1");

            // Füge die weiche Klausel mit Gewicht zu den Zielfunktion hinzu
            // Maximieren: Gewicht * Hilfsvariable
            GRBLinExpr objective = new GRBLinExpr();
            objective.addTerm(5.0, s1); // Gewicht ist 5
            model.setObjective(objective, GRB.MAXIMIZE);

            // Optimieren
            model.optimize();

            // Ergebnisse ausgeben
            if (model.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL) {
                System.out.println("Optimale Lösung gefunden:");
                System.out.println("x1 = " + x1.get(GRB.DoubleAttr.X));
                System.out.println("x2 = " + x2.get(GRB.DoubleAttr.X));
                System.out.println("slack_1 = " + s1.get(GRB.DoubleAttr.X));
                System.out.println("Zielfunktionswert: " + model.get(GRB.DoubleAttr.ObjVal));
            } else {
                System.out.println("Keine optimale Lösung gefunden.");
            }

            // Modell und Umgebung freigeben
            model.dispose();
            env.dispose();

        } catch (GRBException e) {
            System.out.println("Fehler: " + e.getMessage());
        }
    }
}