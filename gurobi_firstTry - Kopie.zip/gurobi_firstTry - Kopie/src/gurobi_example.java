//import gurobi.*;
import com.gurobi.gurobi.*;

public class gurobi_example {
    public static void main(String[] args) {
        try {
            // Create a new environment
            GRBEnv env = new GRBEnv("gurobi.log");
            GRBModel model = new GRBModel(env);

            // Create variables
            GRBVar x = model.addVar(0.0, GRB.INFINITY, 0.0, GRB.CONTINUOUS, "x");
            GRBVar y = model.addVar(0.0, GRB.INFINITY, 0.0, GRB.CONTINUOUS, "y");

            // Set objective: maximize x + y
            GRBLinExpr obj = new GRBLinExpr();
            obj.addTerm(1.0, x);
            obj.addTerm(1.0, y);
            model.setObjective(obj, GRB.MAXIMIZE);

            // Add constraint: x + 2y <= 4
            GRBLinExpr constraint1 = new GRBLinExpr();
            constraint1.addTerm(1.0, x);
            constraint1.addTerm(2.0, y);
            model.addConstr(constraint1, GRB.LESS_EQUAL, 4.0, "c1");

            // Add constraint: x + y >= 1
            GRBLinExpr constraint2 = new GRBLinExpr();
            constraint2.addTerm(1.0, x);
            constraint2.addTerm(1.0, y);
            model.addConstr(constraint2, GRB.GREATER_EQUAL, 1.0, "c2");

            // Optimize the model
            model.optimize();

            // Print results
            System.out.println("x: " + x.get(GRB.DoubleAttr.X));
            System.out.println("y: " + y.get(GRB.DoubleAttr.X));
            System.out.println("Objective value: " + model.get(GRB.DoubleAttr.ObjVal));

            // Dispose of the model and environment
            model.dispose();
            env.dispose();
        } catch (GRBException e) {
            System.out.println("Error code: " + e.getErrorCode() + ". " + e.getMessage());
        }
    }
}
