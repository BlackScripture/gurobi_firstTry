import com.gurobi.gurobi.*;

import java.util.HashMap;
import java.util.Map;
import java.util.Scanner;

public class OneSolverNxN {

    public static void main(String[] args) {

        //Gib Dimensionierung und Anzahl der Farben ein
        Scanner scanner = new Scanner(System.in);

        System.out.print("Gib einen Wert für die Dimensionierung ein: ");
        int ersterWert = scanner.nextInt();

        System.out.print("Gib einen Wert für die Anzahl möglicher auftretender Farben ein: ");
        int zweiterWert = scanner.nextInt();

        scanner.close();

        System.out.println("Dimensionierung: " + ersterWert + "x" + ersterWert);
        System.out.println("Anzahl möglicher verschiedener Farben: " + zweiterWert);

        // Erstelle ein Objekt der puzzleManager-Klasse
        PuzzleManager puzzlemanager = new PuzzleManager();

        PuzzleAndPieces puzzleandpieces = puzzlemanager.createPuzzleAndPieces(ersterWert, zweiterWert);

        PuzzleField[] fields = puzzleandpieces.puzzle;
        PuzzlePiece[] pieces = puzzleandpieces.pieces;

        //erstelle unlösbares Puzzle indem eine ungerade Anzahl an Farbkanten erzeugt wird
        /*
        if (pieces[0].edges[0][0] != 0){
            pieces[0].edges[0][0] = pieces[0].edges[0][0] + 1;
            pieces[0].edges[1][1] = pieces[0].edges[1][1] + 1;
            pieces[0].edges[2][2] = pieces[0].edges[2][2] + 1;
            pieces[0].edges[3][3] = pieces[0].edges[3][3] + 1;
        } else {
            pieces[0].edges[0][2] = pieces[0].edges[0][2] + 1;
            pieces[0].edges[1][3] = pieces[0].edges[1][3] + 1;
            pieces[0].edges[2][0] = pieces[0].edges[2][0] + 1;
            pieces[0].edges[3][1] = pieces[0].edges[3][1] + 1;
        }
         */

        long start = System.nanoTime();

        /////////////////////////
        /////////////////////////
        //Hier startet Gurobi Modell
        /////////////////////////
        /////////////////////////

        try {
            // Erstelle ein neues Gurobi-Modell
            GRBEnv env = new GRBEnv(true);
            env.set("logFile", "OneSolverNxN.log");
            env.start();
            GRBModel model = new GRBModel(env);

            //Array zum speichern aller Variablen
            int variablenAnzahl = (ersterWert*ersterWert)*(ersterWert*ersterWert)*4;
            GRBVar[] vars = new GRBVar[variablenAnzahl];

            // Erstelle Hashmap um später alle Teile in allen Rotationen auf die Felder zu mappen
            Map<String, Integer> varMap = new HashMap<>();
            int varCount = 0;

            // Variablen definieren: jedes Feld mit jedem Puzzleteil in jeder Rotation
            // füge sie anschließend der Hashmap hinzu
            for (int feld_index = 0; feld_index < fields.length; feld_index++) {            // field_index iteriert durch jedes Feld
                for (int piece_index = 0; piece_index < pieces.length; piece_index++) {     // piece_index iteriert durch jedes Puzzleteil
                    for ( int rotation = 0; rotation < 4; rotation++ ) {                    // rotation iteriert durch jede Rotation eines Puzzleteils
                        String belegungString = "field_" + feld_index + "_piece_" + pieces[piece_index].piece_id + "_rotation_" + rotation;
                        // mappe nun auf jedes Feld jedes Puzzleteil in jeder Rotation
                        varMap.put(belegungString, varCount);
                        vars[varCount] = model.addVar(0, 1, 0, GRB.BINARY, belegungString); // Hier die Variablen erstellen

                        //System.out.println(varMap.get(belegungString));
                        varCount++;
                    }
                }
            }

            // Hilfsvariable für die weiche Klausel
            GRBVar s1 = model.addVar(0, 1, 0, GRB.BINARY, "slack_1");

            GRBLinExpr expr = new GRBLinExpr();
            expr.addTerm(1.0, vars[0]);
            expr.addTerm(1.0, vars[1]);
            expr.addTerm(1.0, s1);
            model.addConstr(expr, GRB.EQUAL, 1, "soft_clause_1");

            // Füge die weiche Klausel mit Gewicht zu den Zielfunktion hinzu
            // Maximieren: Gewicht * Hilfsvariable
            GRBLinExpr objective = new GRBLinExpr();
            objective.addTerm(5.0, s1); // Gewicht ist 5
            model.setObjective(objective, GRB.MAXIMIZE);

            // Optimieren
            model.optimize();

            // Ergebnisse ausgeben
            if (model.get(GRB.IntAttr.Status) == GRB.Status.OPTIMAL) {
                System.out.println("Optimale Lösung gefunden:");
                System.out.println("x1 = " + vars[0].get(GRB.DoubleAttr.X));
                System.out.println("x2 = " + vars[1].get(GRB.DoubleAttr.X));
                System.out.println("slack_1 = " + s1.get(GRB.DoubleAttr.X));
                System.out.println("Zielfunktionswert: " + model.get(GRB.DoubleAttr.ObjVal));
            } else {
                System.out.println("Keine optimale Lösung gefunden.");
            }

/*
            if ( vars[0].get(GRB.DoubleAttr.X) == 1.0 ){
                System.out.println(varMap.get("field_" + 0 + "_piece_" + pieces[0].piece_id + "_rotation_" + 0));
            }
            if ( vars[1].get(GRB.DoubleAttr.X) == 1.0 ){
                System.out.println(varMap.get("field_" + 0 + "_piece_" + pieces[0].piece_id + "_rotation_" + 1));
            }

 */

            // Modell und Umgebung freigeben
            model.dispose();
            env.dispose();



        } catch (GRBException e) {
            System.out.println("Fehler: " + e.getMessage());
        }

        /////////////////////////
        /////////////////////////
        //Hier endet Gurobi Modell
        /////////////////////////
        /////////////////////////

        long end = System.nanoTime();
        long elapsedTime = end - start;
        double elapsedTimeInSecond = (double) elapsedTime / 1_000_000_000;
        System.out.println("Runtime:" + elapsedTimeInSecond + " seconds");

    }
}


