import com.gurobi.gurobi.*;

public class WeightedClauses {
    public static void main(String[] args) {
        try {
            // Erstelle ein Gurobi-Umfeld und ein Modell
            GRBEnv env = new GRBEnv(true);
            env.set("logFile", "weighted_clauses.log");
            env.start();
            GRBModel model = new GRBModel(env);

            // Binäre Variablen hinzufügen
            GRBVar x1 = model.addVar(0, 1, 0, GRB.BINARY, "x1");
            GRBVar x2 = model.addVar(0, 1, 0, GRB.BINARY, "x2");
            GRBVar x3 = model.addVar(0, 1, 0, GRB.BINARY, "x3");

            // Klauseln als Nebenbedingungen modellieren
            // (x1 OR NOT x2): x1 + (1 - x2) >= 1
            GRBLinExpr clause1 = new GRBLinExpr();
            clause1.addTerm(1.0, x1);
            clause1.addTerm(-1.0, x2);
            model.addConstr(clause1, GRB.GREATER_EQUAL, -1.0, "clause1");

            // (NOT x1 OR x3): (1 - x1) + x3 >= 1
            GRBLinExpr clause2 = new GRBLinExpr();
            clause2.addConstant(1.0);
            clause2.addTerm(-1.0, x1);
            clause2.addTerm(1.0, x3);
            model.addConstr(clause2, GRB.GREATER_EQUAL, 1.0, "clause2");

            // (x2): x2 >= 1
            GRBLinExpr clause3 = new GRBLinExpr();
            clause3.addTerm(1.0, x2);
            model.addConstr(clause3, GRB.GREATER_EQUAL, 1.0, "clause3");

            // Zielfunktion erstellen: 3*x1 + 5*x2 + 2*x3
            GRBLinExpr objective = new GRBLinExpr();
            objective.addTerm(3.0, x1);
            objective.addTerm(5.0, x2);
            objective.addTerm(2.0, x3);

            model.setObjective(objective, GRB.MAXIMIZE);

            // Optimierung starten
            model.optimize();

            // Ergebnisse ausgeben
            System.out.println("Lösung:");
            System.out.println("x1 = " + x1.get(GRB.DoubleAttr.X));
            System.out.println("x2 = " + x2.get(GRB.DoubleAttr.X));
            System.out.println("x3 = " + x3.get(GRB.DoubleAttr.X));

            // Speicher freigeben
            model.dispose();
            env.dispose();
        } catch (GRBException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }
}